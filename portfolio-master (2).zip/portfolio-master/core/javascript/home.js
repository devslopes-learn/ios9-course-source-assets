"use strict";
var app = angular.module("mainApp.home",["ngRoute"]);
app.config(["$routeProvider", function($routeProvider) {
  $routeProvider.when("/home" , {
    controller: "homeController",
    templateUrl: "core/templates/home.tpl.html"
  })
}]);

app.controller("homeController", ["$scope", "$location", "anchorSmoothScroll", "portfolioData", function($scope, $location, anchorSmoothScroll, portfolioData) {
  $scope.gotoElement = function (eID){
    $location.hash('bottom');
    anchorSmoothScroll.scrollTo(eID);
  };
  $scope.loadProjects = function() {
    $scope.projects = portfolioData.getData();
  };
  $scope.addIndex = function(project) {
    if(project.index > project.images.length -1) {
      project.index = 0;
    } else {
      project.index += 1;
    }
  };
  $scope.subIndex = function(project) {
    if(project.index < 0) {
      project.index = project.images.length -1;
    } else {
      project.index -= 1;
    }
  };
}]);
