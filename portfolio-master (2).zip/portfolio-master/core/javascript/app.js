"use strict";
var app = angular.module("mainApp",["ngRoute","mainApp.home"]);
app.config(["$routeProvider", function($routeProvider) {
  $routeProvider.when("/" , {
    redirectTo: "/home"
  })
  .otherwise({
    redirectTo: "/home"
  });
}]);

app.controller("navController", ["$scope", "$location", "anchorSmoothScroll", function($scope, $location, anchorSmoothScroll) {
  $scope.gotoElement = function (eID){
    $location.hash('bottom');
    anchorSmoothScroll.scrollTo(eID);
  };
}]);
