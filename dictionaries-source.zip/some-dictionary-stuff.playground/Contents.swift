//: Playground - noun: a place where people can play

import UIKit

var webster: [String: String] = ["krill":"any of the small crustaceans","fire":"a burning mass of material"]

var anotherDictionary: [Int: String] = [44: "My fav number", 32: "Man I hate this number!"]

if let krill = webster["krill"] {
    print(krill)
}

webster = [:]

if webster.isEmpty {
    print("Our dictionary is quite the empty!")
}

var highScore: [String: Int] = ["spentak": 401, "playa21": 200, "deathBySpongebob": 500]

for (user, score) in highScore {
    print("\(user): \(score)")
}

highScore["jkkillabeanz"] = 2

for (user, score) in highScore {
    print("\(user): \(score)")
}
