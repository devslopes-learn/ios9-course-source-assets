//: Playground - noun: a place where people can play

import UIKit

var webster: [String: String] = ["krill":"any of the small crustaceans","fire":"a burning mass of material"]


print(webster["krill"]!)

webster["krill"] = "Small fry or fish"

print(webster["krill"]!)

//Clear dictionary
webster = [:]

print(webster["krill"])

if webster.isEmpty {
    print("Our dictionary is empty")
}

var highScore: [String: Int] = ["spentak":344, "jboom":515, "madSkillz":201]

if let burlywoodScore = highScore["burlywood"] {
    print(burlywoodScore) //We never get here but this is a SAFE way to use elements in a dictionary
}

//Iterate through dictionary

for (user, score) in highScore {
    print("\(user): \(score)")
}
