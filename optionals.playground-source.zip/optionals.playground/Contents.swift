//: Playground - noun: a place where people can play

import UIKit


var lotteryWinnings: Int?

//print(lotteryWinnings!) We dont have any winnings so we have a crash

//lotteryWinnings = 1000000
//print(lotteryWinnings!) No crash, but still bad practice

//USE OPTIONALS WHEN THE VARIABLE IS NOT GUARANTEED TO RECEIVE A VALUE

//How to work with optionals:

if lotteryWinnings != nil {
    print(lotteryWinnings!)
}

//OR

if let winnings = lotteryWinnings {
    print(winnings)
}

class  Car {
    var model: String?
}

var vehicle: Car?

if let aCar = vehicle, let aModel = aCar.model { //multiple if lets on same line
    
}

var cars: [Car]?

cars = [Car]()

if let carArr = cars where carArr.count > 0 {
    //We only get here if cars != nil AND if it has more than 0 elements
}

class Person {
    var age: Int! //We (as the developer) are promising that this will have a value
    
    func setAge(newAge: Int) {
        self.age = newAge
    }
}

class Dog {
    var species: String //If not using? or ! you must initialize value in constructor
    
    init(someSpecies: String) {
        self.species = someSpecies
    }
}

//class Life {
//    var sucks: Bool! //<-- can be dangerous
//    var totalMoney: Int!
//    var ageIDie: Int!
//}

class Life {
    private var _sucks: Bool!
    private var _totalMoney: Int!
    private var _ageIDie: Int!
    
    var sucks: Bool {
        if _sucks == nil {
            _sucks = true
        }
        
        return _sucks
    }
    
    var totalMoney: Int {
        if _totalMoney == nil {
            _totalMoney = 0
        }
        
        return _totalMoney
    }
    
    func getMarried() -> Bool {
        if sucks {
            return true
        } else {
            return false
        }
    }
    
}

var life: Life?

print(life?.getMarried()) //This will not crash - just wont do anything


/*

“You specify optional chaining by placing a question mark (?) after the optional value on which you wish to call a property, method or subscript if the optional is non-nil. This is very similar to placing an exclamation mark (!) after an optional value to force the unwrapping of its value. The main difference is that optional chaining fails gracefully when the optional is nil, whereas forced unwrapping triggers a runtime error when the optional is nil.”

Excerpt From: Apple Inc. “The Swift Programming Language.” iBooks. https://itun.es/us/jEUH0.l

*/
