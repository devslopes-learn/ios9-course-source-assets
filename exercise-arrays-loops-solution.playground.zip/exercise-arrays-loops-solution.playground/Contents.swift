//: Playground - noun: a place where people can play

import UIKit


var oddNumbers = [Int]()
var sums = [Int]()

for var z = 1; z <= 100; z++ {
    if z % 2 != 0 {
        oddNumbers.append(z)
    }
}

for num in oddNumbers {
    sums.append(num + 5)
}

var x = 0;
repeat {
    print("The sum is: \(sums[x])")
    x++
} while x < sums.count;

print(sums)