//: Playground - noun: a place where people can play

import UIKit

var helloWorld = "Hello, playground" //String
//helloWorld += " i'm so cool!"
helloWorld = helloWorld + " i'm so cool!"

var numA = 1.5 //Double
var numB: Float = 1.5 //Float
var numC = 3 //Int

var sum = 5 + 6
var product = 5 * 5
var divisor = 20 / 5
var remainder = 22 % 5
var sub = 44 - 22

var crazyResult = sum * product + (divisor * remainder + sub)

var newStr = "Hey " + "how are you?"
var firstName = "Jon"
var lastName = "Smith"

var fullName = "\(firstName) \(lastName)"

var price = "Price: $\(numA)"

price = "Banana"


let total = 5.1 * 6.8

var jack = 0, jill = 1, bob = 2

jill = 6

let beaver = "beaver", stever = "stever", cleaver = "clever"

var totalPrice: Double

totalPrice = 5.5

var sumStr: String = "This is a String"
