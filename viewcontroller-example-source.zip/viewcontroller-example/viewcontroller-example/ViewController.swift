//
//  ViewController.swift
//  viewcontroller-example
//
//  Created by Mark Price on 8/14/15.
//  Copyright © 2015 devslopes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //Only called ONCE when first loaded in memory
    override func viewDidLoad() {
        super.viewDidLoad()
        //refresh table
        
        view.backgroundColor = UIColor.greenColor()
    }

    //Called right before views appear on screen
    //Called EVERY time
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        //refresh table
    }
    
    //Put code that modifies view layout if viewwillappear doesn't work
    override func viewDidLayoutSubviews() {
        
    }

}

