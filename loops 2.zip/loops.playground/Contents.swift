//: Playground - noun: a place where people can play

import UIKit

var ages = [23,25,41,51,62]

if ages[0] >= 50 || ages[1] >= 50 || ages[2] >= 50 || ages[3] >= 50 {
    print("You are almost kind of old. But if you are 50 or over and watching this video you are super cool and in my eyes you aren't so old")
}


for var x = 0; x < ages.count; x++ {
    var age = ages[x]
    
    if age >= 50 {
        print("You are 50 or older!")
    }
}

