//
//  ViewController.swift
//  tapper
//
//  Created by Mark Price on 7/28/15.
//  Copyright © 2015 devslopes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tapsLbl: UILabel!
    @IBOutlet weak var howManyTextField: UITextField!
    @IBOutlet weak var tapBtn: UIButton!
    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var logo: UIImageView!
    
    var maxTaps:Int!
    var currentTaps:Int = 0
    
    //This function returns true or false based on whether
    //the game is over
    func isGameOver() -> Bool {
        if currentTaps >= maxTaps {
            return true
        } else {
            return false
        }
    }
    
    //This is called when we want the game to restart
    func restartGame() {
        
        //Reset max taps back to 0 so the user can specify a new max taps
        maxTaps = 0
        
        //Make the text field empty
        howManyTextField.text = ""
        
        //Set current taps back to 0
        currentTaps = 0
        
        //Hide and show controls based on desired features
        tapsLbl.hidden = true
        tapBtn.hidden = true
        howManyTextField.hidden = false
        playBtn.hidden = false
        logo.hidden = false
    }
    
    //Called when tapBtn is pressed
    @IBAction func onTap(sender: AnyObject) {
        //Increase tap by 1
        currentTaps++
        
        //Update the taps label to the current taps
        tapsLbl.text = "\(currentTaps) Taps"
        
        //Check if it is a game over after each tap
        //if so, restart the game
        if isGameOver() {
            restartGame()
        }
    }
    
    //Called when playBtn is pressed
    @IBAction func playBtnPressed(sender: AnyObject) {
        
        //Validation testing - if we try and use a nil value the app will crash! (ie What would happen if the user tapped the Play button without entering text in the UITextField
        
        if howManyTextField.text != nil && howManyTextField.text != "" {
            
            //Set max taps to what the user specified
            maxTaps = Int(howManyTextField.text!)
            
            //Set controls hidden and visible based on desired features
            howManyTextField.hidden = true
            playBtn.hidden = true
            tapBtn.hidden = false
            tapsLbl.hidden = false
            logo.hidden = true
            
            //Initialize the taps lbl text
            tapsLbl.text = "\(currentTaps) Taps"
        }
    }
}

