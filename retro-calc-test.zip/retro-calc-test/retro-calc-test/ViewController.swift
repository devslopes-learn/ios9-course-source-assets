//
//  ViewController.swift
//  retro-calc-test
//
//  Created by Mark Price on 7/30/15.
//  Copyright © 2015 devslopes. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    enum Operation: String {
        case Divide = "/" //We could have put anything in these strings (ie "Divide")
        case Multiply = "*"
        case Subtract = "-"
        case Add = "+"
        case Equals = "="
        case Empty = "Empty"
    }
    
    //Label to output operations on screen to
    @IBOutlet weak var outputLbl: UILabel!
    
    var btnSound: AVAudioPlayer!
    
    //This holds the numbers that will make up an operation
    var runningNumber = ""
    
    var leftValStr: String = ""
    var rightValStr: String = ""
    var result: String = ""
    var currentOperation: Operation = Operation.Empty
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let path = NSBundle.mainBundle().pathForResource("btn", ofType: "wav")
        let soundUrl = NSURL(fileURLWithPath: path!)
        
        
        do {
            try btnSound = AVAudioPlayer(contentsOfURL: soundUrl)
            btnSound.prepareToPlay()
        } catch let err as NSError {
            
            //This means that there is a programmer error - maybe we forgot
            //to drag the .wav file in or its named incorrectly etc
            //If we were downloading this file from the Internet, then we
            //could have many legitimate reasons to get here and it might NOT
            //be a programmer error
            print(err.localizedDescription)
        }
        
    }

    
    @IBAction func numberPressed(btn: UIButton!) {
        
        playSound()
        
        runningNumber += "\(btn.tag)"
        outputLbl.text = runningNumber
        
    }

    @IBAction func dividePressed(sender: AnyObject) {
        processOperation(Operation.Divide)
    }

    @IBAction func multiplyPressed(sender: AnyObject) {
        processOperation(Operation.Multiply)
    }
    
    @IBAction func subtractPressed(sender: AnyObject) {
        processOperation(Operation.Subtract)
    }

    @IBAction func addPressed(sender: AnyObject) {
        processOperation(Operation.Add)
    }

    @IBAction func equalsPressed(sender: AnyObject) {
        processOperation(currentOperation)
    }
    
    func processOperation(op: Operation) {
        
        playSound()
        
        //If the current operation stored is NOT empty it means we are ready to
        //to make a calculation, print the result, and store the next operation
        if currentOperation != Operation.Empty {
            
            //We need to make sure that the user didn't click an operation, change their mind and then click a different operation before typing in a number
            if runningNumber != "" {
                rightValStr = runningNumber
                runningNumber = ""
                
                performCalculation(currentOperation)
                
                leftValStr = result
                outputLbl.text = result
                
            }
            
            currentOperation = op
            
            
        } else {
            leftValStr = runningNumber
            runningNumber = ""
            currentOperation = op
        }
    }
    
    func performCalculation(op: Operation) {
        if op == Operation.Divide {
            
            let leftOfDecimal = Double(leftValStr)! / Double(rightValStr)!
            
            result = "\(leftOfDecimal)"
            
        } else if op == Operation.Multiply {
            
            result = "\(Double(leftValStr)! * Double(rightValStr)!)"
            
        } else if op == Operation.Subtract {
            
            result = "\(Double(leftValStr)! - Double(rightValStr)!)"
            
        } else if op == Operation.Add {
            
            result = "\(Double(leftValStr)! + Double(rightValStr)!)"
            
        }

    }
    
    func playSound() {
        //If the user is clicking fast lets just stop the previous sound
        //before we start again
        if btnSound.playing {
            btnSound.stop()
        }
        
        btnSound.play()
    }

}

