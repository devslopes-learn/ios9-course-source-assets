//
//  Vehicle.swift
//  classes
//
//  Created by Mark Price on 8/8/15.
//  Copyright © 2015 devslopes. All rights reserved.
//

import Foundation
