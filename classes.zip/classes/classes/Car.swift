//
//  Vehicle.swift
//  classes
//
//  Created by Mark Price on 8/8/15.
//  Copyright © 2015 devslopes. All rights reserved.
//

import Foundation

//Data Hiding Getters/Setters
class Car {
    var engine = "4 Cylinder"
    private var _color = "Silver"
    var odometer = 0
    
    private var _vin = "123AE1T6R211927371AE"
    
    //Getter (accessor)
    var vin: String {
        return _vin
    }
    
    var color: String {
        get {
            return _color
        }
        set {
            if newValue != "Burgandy" {
                _color = newValue
            }
        }
    }
    
    init(engine: String, color: String) {
        self.engine = engine
        self._color = color
    }
    
    init() {
        
    }
    
    func enterMiles(miles: Int) {
        odometer += miles
    }
}