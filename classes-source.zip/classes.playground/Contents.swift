//: Playground - noun: a place where people can play

import UIKit

//Basic class
class Vehicle {
    var engine = "4 Cylinder"
    var color = "Silver"
    var odometer = 0
    
    init(engine: String, color: String) {
        self.engine = engine
        self.color = color
    }
    
    init() {
        
    }
    
    func enterMiles(miles: Int) {
        odometer += miles
    }
}

var srx = Vehicle(engine: "V6", color: "Blue")
var elDorado = Vehicle()

print(srx.color)
print(elDorado.color)


print(srx.odometer)

srx.enterMiles(10400)

print(srx.odometer)

//Data Hiding Getters/Setters
class Car {
    var engine = "4 Cylinder"
    var color = "Silver"
    var odometer = 0
    
    private var vin = "123AE1T6R211927371AE"
    
    init(engine: String, color: String) {
        self.engine = engine
        self.color = color
    }
    
    init() {
        
    }
    
    func enterMiles(miles: Int) {
        odometer += miles
    }
}

var car = Car()
car.vin = "bah"


