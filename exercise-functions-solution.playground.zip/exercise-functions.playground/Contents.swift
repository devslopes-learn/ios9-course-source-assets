//: Playground - noun: a place where people can play

import UIKit

func add(numA: Double, numB: Double) -> Double {
    return numA + numB
}

func subtract(numA: Int, numB: Int) -> Int {
    return numA - numB
}

func multiply(numA: Float, numB: Float) -> Float {
    return numA * numB
}

func divide(numA: Double, numB: Double) -> Double {
    return numA / numB
}

add(5, numB: 6)
subtract(10, numB: 4)
multiply(12, numB: 12)
divide(30, numB: 6)
