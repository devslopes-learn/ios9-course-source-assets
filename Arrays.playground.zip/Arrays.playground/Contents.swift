//: Playground - noun: a place where people can play

import UIKit

//Array literals
var names = ["Jon","Jacob","Jingle","Heimer","Smith"]

//Array literals
var numbers = [5,61,200,1,76]

var mixed = ["Jon",200,"30", true] //Works but don't do it!

//Define an array of type String
var countries: [String]!

//Initialize empty array
var states = [String]()

//Create an array of size 3 and fill it with default values
var top3colors = [String](count: 3, repeatedValue: "No Color")

//Access elements in an array
top3colors[0] = "Blue"
top3colors[1] = "Red"
top3colors[2] = "Burlywood"

//Adding and remove elements
var favCars = [String]()
favCars.append("BMW M3")
favCars.append("Audio S7")
favCars.append("Ford Pinto") //Who the crap put this here!?
favCars.removeAtIndex(2)
favCars.append("1969 Chevy Camaro")



var shoppingCart = [String]()
var budget = 500.0
var currentCartAmount = 0.0

func addItemToCart(item: String, price: Double) {
    if currentCartAmount + price <= budget {
        shoppingCart.append(item)
        currentCartAmount += price
    } else {
        print("Not enough monies")
    }
}

addItemToCart("Final Fantasy X / X2", price: 50.25)

print(currentCartAmount)

addItemToCart("Bleach", price: 3.45)

print(currentCartAmount)

addItemToCart("Couch", price: 150.72)

print(currentCartAmount)

addItemToCart("PS4", price: 300)

print(currentCartAmount)

print(shoppingCart)

