//: Playground - noun: a place where people can play

import UIKit

var num1 = 15
var num2 = 5
var sum = num1 + num2
var product = 9 * 5
var diff = num1 - num2
var div = num1 / num2

var varA = "AAA", varB = "BBB", varC = "CCC"
let letA = "lettuce", letB = "bettuce", letC = "cettuce"

var myDouble: Double
var someNum: Int = 423

var word = "Hello"
var word2 = "World"
var words = word + " " + word2
words = "\(word) \(word2)"
